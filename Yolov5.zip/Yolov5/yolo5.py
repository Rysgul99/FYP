import torch
import cv2

# Provide the path to your model's weights
model_weights = "last.pt"

# Load the model
model = torch.hub.load('ultralytics/yolov5', 'custom', path=model_weights)

# Initialize the webcam
cap = cv2.VideoCapture(0)

while(cap.isOpened()):
    ret, frame = cap.read()

    if ret:
        # Preprocess the frame
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = model(frame_rgb)

        # Draw the predictions on the frame
        results.render()
        predictions = cv2.cvtColor(results.render()[0], cv2.COLOR_RGB2BGR)

        # Display the frame with bounding boxes
        cv2.imshow('YOLOv5 Webcam', predictions)

        # Break the loop on 'q' keypress
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

# Release the capture and destroy all windows once done
cap.release()
cv2.destroyAllWindows()
